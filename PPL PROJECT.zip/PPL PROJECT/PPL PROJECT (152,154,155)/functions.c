#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <math.h>
#include "list.h"
#include "functions.h"

/*Function to equal the digits after decimal point.*/
void decimalEqual(number *No1, number *No2) {
	int i;
	if(No1->dec > No2->dec) {
		int diff = No1->dec - No2->dec;
		for(i = 0; i < diff; i++) {
			addDigit(No2, '0');
			No2->dec++;
		}
	}
	else if(No2->dec > No1->dec) {
		int diff = No2->dec - No1->dec;
		for(i = 0; i < diff; i++) {
			addDigit(No1, '0');
			No1->dec++;
		}
	}
}

/*equals the length of both numbers by prepending zeros to small number.*/
void lengthEqual(number *No1, number *No2) {
	int gap;
	gap = length(*No1) - length(*No2);
	if(gap > 0) {
		int i = 0;
		while(i < gap) {
			appendleft(No2, 0);
			i++;
		}
	}
	else if(gap < 0) {
		int i = 0;
		gap = -gap;
		while(i < gap) {
			appendleft(No1, 0);
			i++;
		}
	}
}

/*checks whether the number is zero or not. returns 0 if it is zero number.*/
int zeroNumber(number No1) {
	int i, flag = 0;
	node *p = No1.head;
	for(i = 0; i < length(No1); i++) {
		if(p->num != 0)
			flag = 1;
		 p = p->next;
	}
	return flag;
}


/*Addition Operation*/
number *add(number *No1, number *No2) {
	number *ans;
	ans = (number *)malloc(sizeof(number));
	initNumber(ans);
	decimalEqual(No1, No2);
	if(No1->sign != No2->sign) {
		if(No1->sign == MINUS) {
			No1->sign = PLUS;
			ans = sub(No2, No1);
		}
		else if(No2->sign == MINUS) {
			No2->sign = PLUS;
			ans = sub(No1, No2);
		}
	}
	else if(No1->sign == No2->sign) {
		int i, n1, n2, carry = 0, sum;
		int len_a, len_b;
		node *t1 = No1->tail;
		node *t2 = No2->tail;
		len_a = length(*No1);
		len_b = length(*No2);
		if(No1->sign == MINUS)
			ans->sign = MINUS;
		else
			ans->sign = PLUS;
		if(len_a >= len_b) {
			for(i = 1; i <= len_b; i++) {
				n1 = t1->num;
				n2 = t2->num;
				sum = n1 + n2 +carry;
				carry = sum / 10;
				sum = sum % 10;
				appendleft(ans, sum);
				t1 = t1->prev;
				t2 = t2->prev;
			}
			for(i = 1; i <= len_a - len_b; i++) {
				n1 = t1->num;
				sum = n1 + carry;
				carry = sum / 10;
				sum = sum % 10;
				appendleft(ans, sum);
				t1 = t1->prev;
			}
		}else {
			for(i = 1; i <= len_a; i++) {
				n1 = t1->num;
				n2 = t2->num;
				sum = n1 + n2 +carry;
				carry = sum / 10;
				sum = sum % 10;
				appendleft(ans, sum);
				t1 = t1->prev;
				t2 = t2->prev;
			}
			for(i = 1; i <= len_b - len_a; i++) {
				n1 = t2->num;
				sum = n1 + carry;
				carry = sum / 10;
				sum = sum % 10;
				appendleft(ans, sum);
				t2 = t2->prev;
			}
		}
		ans->dec = No1->dec;
		if(carry != 0)
			appendleft(ans, carry);
	}
	return ans;
}

/*Function for finding bigger number among equal length numbers.*/
int compareEqual(number No1, number No2) {
	lengthEqual(&No1, &No2);
	decimalEqual(&No1, &No2);
	node *p, *q;
	int len;
	int i;
	len = length(No1);
	p = No1.head;
	q = No2.head;
	for(i = 1; i <= len; i++) {
		if(p->num > q->num)
			return 1;  /*i.e. number a greater than number b.*/
		else if(p->num < q->num)
			return -1;  /*i.e. a is less than b.*/
		p = p->next;
		q = q->next;
	}
	return 0;    /*i.e. both numbers are equal.*/
}
/*Substraction operation.*/
number *sub(number *No1, number *No2) {
	number *ans;
	ans = (number *)malloc(sizeof(number));
	initNumber(ans);
	/*decimal digits and length made equal.*/
	decimalEqual(No1, No2);
	lengthEqual(No1, No2);
	/*zeroRemov(No1);*/
	/*zeroRemov(No2);*/
	if(No1->sign != No2->sign) {
		if(No1->sign == MINUS) {
			No1->sign = PLUS;
			ans = add(No1, No2);
			ans->sign = MINUS;
		}
		else if(No2->sign == MINUS) {
			No2->sign = PLUS;
			ans = add(No1, No2);
			ans->sign = PLUS;
		}
	}
	else if(No1->sign == No2->sign) {
		if(No1->sign == MINUS) {
			No1->sign = No2->sign = PLUS;
			ans = sub(No2, No1);
		}
		else if(No1->sign == PLUS) {
			int n1, n2, diff, borrow = 0, i, len;
			node *t1 = No1->tail;
			node *t2 = No2->tail;
			/*length of both numbers is same now because of lengthEqual.*/
			len = length(*No2);
			if(compareEqual(*No1, *No2) == 1) {
				for(i = 1; i <= len; i++) {
					n1 = t1->num;
					n2 = t2->num;
					n1 = n1 - borrow;
					if(n1 >= n2) {
						diff = n1 - n2;
						borrow = 0;
						appendleft(ans, diff);
					}
					else {
						n1 = n1 + 10;
						diff = n1 - n2;
						borrow = 1;
						appendleft(ans, diff);
					}
					t1 = t1->prev;
					t2 = t2->prev;
				}
			}
			else if(compareEqual(*No1, *No2) == -1) {
				ans->sign = MINUS;
				for(i = 1; i <= len; i++) {
					n1 = t1->num;
					n2 = t2->num;
					n2 = n2 - borrow;
					if(n2 >= n1) {
						diff = n2 - n1;
						borrow = 0;
						appendleft(ans, diff);
					}
					else {
						n2 = n2 + 10;
						diff = n2 - n1;
						borrow = 1;
						appendleft(ans, diff);
					}
					t1 = t1->prev;
					t2 = t2->prev;
				}
			}
			else {
				if(compareEqual(*No1, *No2) == 0) {
					appendleft(ans, 0);
				}
			}
		}
	}
	ans->dec = No1->dec;
	return ans;
}
/*Multiplication Operation.*/
number *mult(number *No1, number *No2) {
	number *ans = (number *)malloc(sizeof(number));
	initNumber(ans);
	/*checks if any one of the numbers is zero.*/
	if((zeroNumber(*No1) == 0) || (zeroNumber(*No2) == 0)) {
		addDigit(ans, '0');
		return ans;
	}
	int lengthdiff;
	if(No1->sign == No2->sign) {
		ans->sign = PLUS;
		No1->sign = No2->sign = PLUS;
	}
	else {
		ans->sign = MINUS;
		No1->sign = No2->sign = PLUS;
	}
	lengthdiff = length(*No1) - length(*No2);
	if(lengthdiff < 0) {
		ans = mult(No2, No1);
		return ans;
	}
	else {
		node *t1, *t2;
		int len_a = length(*No1);
		int len_b = length(*No2);
		int i, j, n1 = 0, n2 = 0;
		int tempresult[2 * len_a];
		for(i = 0; i < 2 *len_a; i++)
			tempresult[i] = 0;
		int k = 2 * len_a - 1;
		t2 = No2->tail;
		for(i = 0; i < len_b; i++) {
			t1 = No1->tail;
			int carry1 = 0, carry2 = 0;
			for(j = k - i; j > len_a - 2; j--) {
				if(t1 != NULL && t2 != NULL) {
					n1 = t1->num * t2->num + carry1;
					t1 = t1->prev;
					carry1 = n1 / 10;
					n1 = n1 % 10;
					n2 = tempresult[j] + n1 + carry2;
					carry2 = n2 / 10;
					n2 = n2 % 10;
					tempresult[j] = n2;
				}
				else {
					break;
				}
			}
			tempresult[j] = carry1 + carry2 + tempresult[j];
			len_a--;
			t2 = t2->prev;
		}
		for(i= k; i >= len_a - 1 && i >= 0; i--) {
			appendleft(ans, tempresult[i]);
		}
		ans->dec = No1->dec + No2->dec;
		return ans;
	}
}
/*Division Operation.*/
number *division(number *m, number *n){
	if(zeroNumber(*n) == 0) {
		printf("Dividing by Zero is not allowed.\n");
		return NULL;
	}
	zeroRemov(m);
	zeroRemov(n);

	int k = m->dec > n->dec ? m->dec : n->dec;
	int i = 0;

	while(i < k) {
		if(m->dec > 0)
			m->dec--;
		else
			addDigit(m, '0');
		if(n->dec > 0)
			n->dec--;
		else
			addDigit(n, '0');
		i++;
	}
	i = 9;
	number *c, *d, *ans, *q, *pro;
	c = (number *)malloc(sizeof(number));
	d = (number *)malloc(sizeof(number));
	ans = (number *)malloc(sizeof(number));
	pro = (number *)malloc(sizeof(number));
	q = (number *)malloc(sizeof(number));

	initNumber(ans);
	initNumber(c);
	initNumber(q);
	initNumber(d);
	if(m->sign == n->sign) {
		q->sign = PLUS;
		m->sign = n->sign = PLUS;
	}
	else {
		q->sign = MINUS;
		m->sign = n->sign = PLUS;
	}
	node *p = m->head;
	char ch = p->num + '0';
	addDigit(d, ch);
	while(q->dec < SCALE){
		while(i >= 0){
			appendleft(c, i);
			pro = mult(n, c);
			ans = sub(d, pro);
			if(ans->sign != MINUS) {
				addDigit(q, i + '0');
				node *tmp = c->head;
				free(tmp);
				c->head = c->tail = NULL;
				break;
			}
			else{
				node *tmp = c->head;
				free(tmp);
				c->head = c->tail = NULL;
				i--;
			}
		}
		d = ans;
		if(p->next != NULL) {
			p = p->next;
			ch = p->num + '0';
			addDigit(d, ch);
		}
		else{
			q->dec++;
			addDigit(d, '0');
		}
		i = 9;
		node *tmp = c->head;
		free(tmp);
		c->head = c->tail = NULL;
	}
	q->dec--;
	return q;
}

/*FORMULA :- remainder = a - floor_division(a/b) * No2*/
number *modulus(number *No1, number *No2) {
	if(zeroNumber(*No2) == 0) {
		printf("ERROR : Modulo by Zero is not allowed.\n");
		return NULL;
	}
	int tempsign;
	if(No1->sign == MINUS) {
		tempsign = MINUS;
		No1->sign = No2->sign = PLUS;
	}
	else {
		tempsign = PLUS;
		No1->sign = No2->sign = PLUS;
	}
	decimalEqual(No1, No2);
	int a_dec = No1->dec;
	number *ans = (number *)malloc(sizeof(number));
	number *temp = (number *)malloc(sizeof(number));
	initNumber(ans);
	initNumber(temp);
	temp = division(No1, No2);
	if(temp->dec != 0) {
		int pos = length(*temp) - 1;
		while(temp->dec != 0) {
			remov(temp, pos);
			temp->dec--;
			pos--;
		}
	}
	temp = mult(temp, No2);
	ans = sub(No1, temp);
	ans->sign = tempsign;
	ans->dec = a_dec;
	return ans;
}
